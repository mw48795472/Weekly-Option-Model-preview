﻿위클리옵션 종목별 CSV 패키지
확보일: 2026-10-11 (시장 관측시각 아님)

weekly_contracts.csv: 고유 계약 766행. 상충하는 식별 속성은 공란+identity_conflict_fields.
weekly_contract_sessions.csv: 원본 26필드와 진단, 미확보 변수. 1258행. 키=cme_tp+series.
products/: 상품군별 고유 계약 CSV 4개.
symbols/: 계약코드별 CSV 766개. 각 파일 1~2행, 주간·야간 원값 보존.
variable_dictionary.csv: 변수별 의미·실제 예시·범위·공란 수·분석 용도. 분모는 세션 원장.
variable_value_counts.csv: 모든 관측값의 빈도. 서로 다른 세션을 독립 계약으로 세지 마세요.
product_expiry_session_summary.csv: 상품·만기·세션별 행사가 범위와 관측 간격. 공식 행사가 간격/누락 판정이 아님.
analysis_readiness.csv: 지금 가능한 분석과 필요한 다음 자료.
poc_assumptions.csv: 가정값만 분리. 종목별 시장 관측값에 섞지 않습니다.

UTF-8 BOM. Excel에서는 데이터 > 텍스트/CSV로 가져오기, 코드 열을 텍스트로 지정하세요(001/03 등 0 보존).
빈칸은 미확보/원문 공란/세션 부재입니다. 0이 아닙니다. market_data_status와 변수 사전을 확인하세요.
exp_ym-rem_cnt는 진단값이며 공표일이 아닙니다. calendar_dte_at_snapshot은 확보일 기준 달력 차이입니다.
upper_p_lv1/lower_p_lv1은 가격제한 원값으로 bid/ask가 아닙니다.
내재변동성·OI·Greeks·RV는 미확보입니다. 모의 인증 성공은 시세조회 성공을 의미하지 않습니다.
